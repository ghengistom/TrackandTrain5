package com.track.beat.service;

public class SuccessService 
{

	String userid;
	
	public String getUserId(String userId)
	{
		userid = userId;
		return this.userid;
	}
	
	
}
